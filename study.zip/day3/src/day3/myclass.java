package day3;

public class myclass {

	public static void main(String[] args) {
		String[] name = {"�ƹݶ�","�ҳ�Ÿ","�׷���"};
		String[] color = {"W","Y","B"};
//		Car �ƹݶ� = new Car();
//		Car ��Ÿ�� = new Car();
//		Car �׷��� = new Car();
		�ƹݶ�.speed = 100 ;
		�ƹݶ�.color = "W" ;
		�ƹݶ�.speedDown();
		System.out.println(�ƹݶ�.color+�ƹݶ�.speed );
		}
		
	}

class Car{
	// method,overload???
	String color;
	String name;
	int speed;
//	boolean power;
	
//	void power() { power = !power; }
	void speedUp() { ++speed; }
	void speedDown() { --speed; }

public Car(String name,int speed,int color) {
	this.name = name;
	this.speed = speed;
}
}
