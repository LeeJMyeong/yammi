package day2;

public class solo {

	public static void main(String[] args) {
		int [] scores = {50,22,35};
		
		int sum = 0;
		for(int i=0; i<scores.length; i++) {
			sum += scores[i];
		}
		System.out.println("���� :  " + sum);
		
		double avg = (double) sum / scores.length;
		System.out.println("��� :  " + avg);

	}

}
