package day2;

public class study2 {

	public static void main(String[] args) {
		int[][] arr = { {1,2,3} , {4,5,6} , {7,8,9}
		}
		// for
		for (int i = 0; i< 10; i++) {
			System.out.println(i);
		}
		// while(����,����)
		int i = 0;
		while(i< 10) {
			System.out.println(i);
			i++;
		}
		boolean isBreak = true;
		while(isBreak) {
			System.out.println("while");
			i++;
			if(i<5) isBreak = false;
		}
		i = 0;
		do {
			System.out.println(i);
		} while(i< 10);
	}
}

