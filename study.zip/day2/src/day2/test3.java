package day2;

public class test3 {

	public static void main(String[] args) {
		// ���Ϸ� ���� �Ųٷ� ǥ��
		int[][] arr = { {1,2,3} , {4,5,6} , {7,8,9} };
		
//		for(int i=0; 1<arr.length;i++) {
//			for(int j = 0; j<arr[i].length; j++) {
//				System.out.print(arr[arr.length-i-1][arr.length-j-1]);
//			}
//		}
		
		int i = arr.length-1;
		while(i>=0) {
			int j = arr[i].length-1;
			while(j>=0) {
				System.out.println(arr[i][j]);
				j--;
			}
			i--;
		}
		}
}

// 147258369

//int[][] arr = {
//		{1,2,3},
//		{4,5,6},
//		{7,8,9}
//		};
//int i = 0;
//while (i < arr.length) {
//	
//	int j = 0;
//	while (j < arr[i].length) {
//		
//		System.out.print(arr[j][i]);
//		j +=1;		
//	}i += 1;