package day2;

public class test {
//	147258369
//	public static void main(String[] args) {
		int [][] arr = {{1,2,3},{4,5,6},{7,8,9}};
//		
//		for(int i=0; i<arr.length ; i++ );{
//			arr.lenght = 3 0,1,2
//		for(int j=0; j<arr.length ; j++ );{
//			System.out.print(arr[j][i]);
//			
		for	(int i=arr.length; i>0; i--)
			for	(int j=arr[i-1].length; j>0; j--) {
		
				}
			}
		}
	


