package day2;

public class study1 {

	public static void main(String[] args) {
//		string , byte , short , int ,
//		long , float , double , boolean
		int a = 6; // 1 2 3 6
		
		for (int i = a; i>0; i--)
		{
			if	(a % i == 0);
			System.out.println(i);
		}

	}

}
// && and(�Ѵٸ���) || OR (�����ϳ� ����)
