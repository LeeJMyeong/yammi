
public class a123 {

	public static void main(String[] args) {
		// �ݺ���
		int[] arr = {1,2,3,4,5};
		int[][] arr2 = {{1,2,3}, {4,5,6}, {7,8,9}};
		int a = 0;
		for(int i=0; i<arr.length; i++) {
		if(arr[i]%2 == 0); 
		else System.out.println(arr[i]);
		}
	}
}

