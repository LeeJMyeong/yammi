
public class A {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println();
//		1,2,3,4,5�� ����ִ� �迭
		String[] names2 = {};
		String[] names3 = new String[2];
		int[] ints = {};
		int[] arr = {1,2,3,4,5};
		int[] arr2 = new int[2];
	}
	

}
