package day4;

import java.util.Arrays;
import java.util.Scanner;

import javax.print.DocFlavor.STRING;

public class Example3 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Loop : while(true) {
			String[] st = new String[4] ;
			for(int i=0; i<st.length; i++) {
				
				System.out.println("�̸��Է�");
				
				String line = sc.nextLine();
				
				System.out.println("�����Է�");
			
				String line2 = sc.nextLine();
				
				int age = Integer.parseInt(line2);
		
				st[i] = line;
			
				if(line.equals("q")) break Loop;
		}
		
		System.out.println(Arrays.toString(st));
		}
		System.out.println("end");
	}

}
