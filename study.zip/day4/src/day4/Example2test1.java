package day4;

import java.util.ArrayList;
import java.util.List;

public class Example2test1 {

	public static void main(String[] args) {
		//name �� age �� ������ �ִ� person�� ����
//	    intput ������:
//	    {name:park,age:20}, {name:kim,age14},{name:lee,age24},
//	    ���ذ� ������ �ѻ� �Ծ���� �ѻ� �� ���̰� ����϶�
//	    output :
//	    [{name:park,age:21},{name:kim,age:15},{name:lee,age:25}]
	Person person1 = new Person("park",20);
	Person person2 = new Person("kim", 14);
	Person person3 = new Person("lee", 24);
	List<Person> persons = new ArrayList<Person>();
	persons.add(person1);
	persons.add(person2);
	persons.add(person3);
	for(int i=0; i < persons.size(); i++ ) {
		Person tmp1 = persons.get(i);
		Person p = new Person(tmp1.getName(), tmp1.getAge()+1);
		persons.set(i, p);
	}
	for(Person person: persons) {
		person.setAge(person.age);
	}
	}
	
			
		}

	}

class Person{
	private String name;
	int age;
	public Person(String name, int age) {
		this.age = age;
		this.name = name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getName() {
		return name;
}
	public int getAge() {
		return age;
}

}