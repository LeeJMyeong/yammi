package unit;

import data.Unit;

public class Marine extends Unit{
	
	public Marine() {
		super("Marine", 50, 10);
	}

}
