package unit;

import data.Unit;

public class Zealot extends Unit{
	private int shield = 10;
	
	public Zealot() {
		super("Zealout", 100, 12);
	}
	@Override

	public String getDamage(Unit unit) {
		if(shield < 0 ) {
		return super.getDamage(unit) + super.getDamage(unit);
//		return super.getName() +"��  "+ unit.getName()() + "���� " + unit.getAttackPoint() + "���� �޾Ҵ�";
		}else {
			shield -= unit.getAttackPoint();
			return getName()+"�� " + unit.getName() + "���� " + unit.getAttackPoint() + "���� �޾Ҵ�";
		}
	}
}