package data;

abstract public class Unit extends Player{
	static int count = 0;
	private int id;
	private String name;
	private int hp;
	private int attackPoint;
	private int shield;
//	"�ǹ�","��Ҵ�","�׾���"
	private UStatus status; // ����Ʈ�� ���ص���
	
	public Unit(String name,int hp, int attackPoint) {
		this.name = name;
		this.attackPoint = attackPoint;
		this.hp = hp;
		count++;
		id = count; 
}
	public String attack() {
		return name +"��  "+ attackPoint + "���� ����ϴ�";
	}
	public String getDamage(Unit unit) {
		this.hp = this.hp - unit.attackPoint;
		return name +"��  "+ unit.getName() + "���� " + unit.getAttackPoint() + "���� �޾Ҵ�";
	}
	public int getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getHp() {
		return hp;
	}
	public void setHp(int hp) {
		this.hp = hp;
	}
	public int getAttackPoint() {
		return attackPoint;
	}
	public void setshield(int shield) {
		this.shield = shield;
	}
	public void setAttackPoint(int attackPoint) {
		this.attackPoint = attackPoint;
	}
	
	@Override
	public String toString() {
		return "Unit [name=" + name + ", hp=" + hp + ", attackPoint=" + attackPoint + ", shield=" + shield + "]";
		
	
	}
	
	

	}

