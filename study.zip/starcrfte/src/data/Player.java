package data;

public class Player {
	private int persons=0;
	public int getPersons() {
		return persons;
	}

}
