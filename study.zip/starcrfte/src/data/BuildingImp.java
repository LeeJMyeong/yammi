package data;

 public class BuildingImp  {
	private String name;
}
