package data;

public enum UStatus {
	BUIDING , LIVE , DEAD

}
